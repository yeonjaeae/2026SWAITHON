/* 결과 양식: 로컬 설계 미리보기, 분석 지표는 미연결 상태 유지 */
const ready=Boolean(App.state.region)&&App.coverage(App.state.rectangles).green>0;
document.getElementById('emptyResult').hidden=ready;
document.getElementById('resultContent').hidden=!ready;
if(ready){
  document.getElementById('resultName').textContent=App.state.name;
  App.renderMap(document.getElementById('beforeMap'),[]);
  App.renderMap(document.getElementById('afterMap'));
  document.getElementById('summary').textContent=App.summary();
  document.getElementById('resultMemo').textContent=App.state.memo?'메모: '+App.state.memo:'메모 없음';
}
