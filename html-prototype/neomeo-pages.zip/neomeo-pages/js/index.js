/* 공간 탐색 양식: 지도 드래그 → 설계할 범위 전달 */
const map = document.getElementById('exploreMap');
const layer = document.getElementById('selectionLayer');
const status = document.getElementById('selectionStatus');
let selection = App.state.region;
let mapMode='pan';
const camera=App.bindCamera(map,{width:900,height:500,canPan:()=>mapMode==='pan',onChange:value=>document.getElementById('exploreZoom').textContent=value+'%'});
function setMode(mode){
  mapMode=mode;map.style.cursor=mode==='pan'?'grab':'crosshair';
  for(const [id,key] of [['explorePan','pan'],['exploreSelect','select']]){
    const b=document.getElementById(id);b.setAttribute('aria-pressed',mode===key);b.className=mode===key?'':'secondary';
  }
  status.textContent=mode==='pan'?'드래그하여 이동 · 마우스 휠로 확대·축소':'대각선으로 드래그하여 설계 범위를 선택하세요.';
}
document.getElementById('explorePan').onclick=()=>setMode('pan');
document.getElementById('exploreSelect').onclick=()=>setMode('select');
document.getElementById('explorePlus').onclick=()=>camera.zoom(1.5);
document.getElementById('exploreMinus').onclick=()=>camera.zoom(1/1.5);
document.getElementById('exploreHome').onclick=()=>camera.reset();
setMode('pan');
document.getElementById('siteName').value=App.state.name;
function showSelection(box) {
  App.drawRects(layer,box?[box]:[]);
  document.getElementById('startDesign').disabled=!selection;
}
showSelection(selection);
if(selection)status.textContent='이전에 선택한 범위를 불러왔습니다.';
App.bindDrawing(map,{width:900,height:500,enabled:()=>mapMode==='select',
  onPreview:box=>showSelection(box||selection),
  onCommit:box=>{selection=box;showSelection(box);status.textContent='범위를 선택했습니다. 이름을 입력하고 설계를 시작하세요.';}
});
document.getElementById('reset').onclick=()=>{
  selection=null;showSelection(null);status.textContent='지도 위를 대각선으로 드래그해 주세요.';
};
document.getElementById('startDesign').onclick=()=>{
  if(!selection)return;
  // 같은 범위로 돌아가면 작성 중이던 설계를 유지합니다.
  if(JSON.stringify(selection)!==JSON.stringify(App.state.region)) {
    App.state.rectangles=[];App.state.photo=null;
  }
  App.state.region=selection;
  App.state.name=document.getElementById('siteName').value.trim()||'직접 선택한 공간';
  if(App.save())location.href='design.html';
};
