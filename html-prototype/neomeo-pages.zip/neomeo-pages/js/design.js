/* 공존 설계: 녹화 영역은 직접 그리며 식생 구성은 비율 슬라이더로 입력합니다. */
const drawingMap=document.getElementById('designMap');
const hasSelection=Boolean(App.state.region);
document.getElementById('noSelection').hidden=hasSelection;
document.getElementById('designWorkspace').hidden=!hasSelection;
let mode='green';
const camera=App.bindCamera(drawingMap,{width:1000,height:700,canPan:()=>mode==='pan',onChange:value=>document.getElementById('designZoom').textContent=value+'%'});
document.getElementById('designPlus').onclick=()=>camera.zoom(1.5);
document.getElementById('designMinus').onclick=()=>camera.zoom(1/1.5);
document.getElementById('designHome').onclick=()=>camera.reset();
document.getElementById('designPan').onclick=()=>setMode('pan');
let history=[];
let photoLoading=false;
const rectangleLayer=App.renderMap(drawingMap);
const previewLayer=App.svg('g');drawingMap.append(previewLayer);
document.getElementById('designName').textContent=App.state.name||'설계 대상';
function checkpoint(){ history.push(structuredClone(App.state.rectangles)); }
function refresh() {
  App.drawRects(rectangleLayer,App.state.rectangles);
  const areas=App.coverage(App.state.rectangles);
  document.getElementById('greenRatio').textContent=App.percent(areas.green);
  document.getElementById('protectRatio').textContent='보존 영역 '+App.percent(areas.protect);
  document.getElementById('rectCount').textContent=App.state.rectangles.length+'개';
  document.getElementById('undo').disabled=!history.length;
  document.getElementById('clear').disabled=!App.state.rectangles.length;
  document.getElementById('viewResult').disabled=areas.green<=0||photoLoading;
  const list=document.getElementById('rectList');list.replaceChildren();
  App.state.rectangles.forEach((box,index)=>{
    const li=document.createElement('li'), label=document.createElement('span'), button=document.createElement('button');
    label.textContent=`${index+1}. ${box.kind==='protect'?'보존':'녹화'} 영역`;
    button.textContent='삭제';button.className='secondary';button.setAttribute('aria-label',label.textContent+' 삭제');
    button.onclick=()=>{checkpoint();App.state.rectangles.splice(index,1);refresh();App.save();};
    li.append(label,button);list.append(li);
  });
}
function setMode(next) {
  mode=next;drawingMap.style.cursor=mode==='pan'?'grab':'crosshair';
  for(const [id,kind] of [['greenTool','green'],['protectTool','protect'],['designPan','pan']]){
    const button=document.getElementById(id);button.setAttribute('aria-pressed',kind===mode);
    button.className=kind===mode?'':'secondary';
  }
  document.getElementById('drawStatus').textContent=mode==='pan'?'드래그하여 지도 이동 · 마우스 휠로 확대·축소':(mode==='green'?'녹화':'보존')+'할 영역을 사각형으로 드래그하세요. Esc 키로 그리기를 취소할 수 있습니다.';
}
document.getElementById('greenTool').onclick=()=>setMode('green');
document.getElementById('protectTool').onclick=()=>setMode('protect');
App.bindDrawing(drawingMap,{width:1000,height:700,enabled:()=>mode!=='pan'&&!photoLoading,
  onPreview:box=>{if(!photoLoading)App.drawRects(previewLayer,box?[{...box,kind:mode}]:[]);},
  onCommit:box=>{
    if(!hasSelection||photoLoading)return;
    checkpoint();App.state.rectangles.push({...box,kind:mode});refresh();App.save();
    document.getElementById('drawStatus').textContent='영역을 추가했습니다. 다른 위치에도 이어서 그릴 수 있습니다.';
  }
});
document.getElementById('undo').onclick=()=>{
  if(history.length){App.state.rectangles=history.pop();refresh();App.save();}
};
document.getElementById('clear').onclick=()=>{checkpoint();App.state.rectangles=[];refresh();App.save();};
function refreshMix(){
  for(const key of ['grass','shrub','tree']){
    const value=App.state.vegetationMix[key],input=document.getElementById(key);
    input.value=value;input.style.setProperty('--progress',value+'%');
    document.getElementById(key+'Value').textContent=value+'%';
  }
}
for(const key of ['grass','shrub','tree']){
  document.getElementById(key).oninput=event=>{
    App.state.vegetationMix=App.rebalanceMix(App.state.vegetationMix,key,Number(event.target.value));
    refreshMix();App.save();
  };
}
refreshMix();
const memo=document.getElementById('memo');memo.value=App.state.memo;
memo.oninput=()=>{App.state.memo=memo.value;App.save();};
document.getElementById('viewResult').onclick=()=>{if(App.coverage(App.state.rectangles).green>0&&App.save())location.href='result.html';};
// 사용자 사진은 브라우저 안에서만 처리하고 서버로 전송하지 않습니다.
document.getElementById('sitePhoto').onchange=async event=>{
  const file=event.target.files[0];if(!file)return;
  photoLoading=true;refresh();
  try {
    const bitmap=await createImageBitmap(file);
    const canvas=document.createElement('canvas');
    const scale=Math.min(1,1400/Math.max(bitmap.width,bitmap.height));
    canvas.width=Math.round(bitmap.width*scale);canvas.height=Math.round(bitmap.height*scale);
    canvas.getContext('2d').drawImage(bitmap,0,0,canvas.width,canvas.height);bitmap.close();
    const previous={photo:App.state.photo,rectangles:App.state.rectangles};
    App.state.photo=canvas.toDataURL('image/jpeg',.85);App.state.rectangles=[];
    if(!App.save()){Object.assign(App.state,previous);return;}
    // 새 배경에 맞춰 레이어를 갱신하고 기존 객체 참조를 유지합니다.
    camera.reset();App.renderMap(drawingMap,[]);
    drawingMap.lastChild.replaceWith(rectangleLayer);drawingMap.append(previewLayer);
    history=[];
    document.getElementById('drawStatus').textContent='배경을 변경했습니다. 새 사진 위에 녹화 영역을 그려주세요. 사진은 화면에 맞춰 일부 잘릴 수 있습니다.';
  } catch(_){document.getElementById('drawStatus').textContent='사진을 읽지 못했습니다. 다른 이미지 파일을 선택해 주세요.';}
  finally{photoLoading=false;refresh();}
};
refresh();
