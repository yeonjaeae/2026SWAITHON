/* 리포트 양식: 사용자 입력과 화면 좌표를 파일로 저장 */
const ready=Boolean(App.state.region)&&App.coverage(App.state.rectangles).green>0;
document.getElementById('emptyReport').hidden=ready;
document.getElementById('reportContent').hidden=!ready;
if(ready){
  document.getElementById('reportName').textContent=App.state.name;
  document.getElementById('reportDate').textContent=new Date().toLocaleDateString('ko-KR');
  document.getElementById('summary').textContent=App.summary();
  document.getElementById('reportMemo').textContent=App.state.memo?'메모: '+App.state.memo:'메모 없음';
  App.renderMap(document.getElementById('reportMap'));
}
document.getElementById('print').onclick=()=>window.print();
document.getElementById('download').onclick=()=>{
  const {photo,...data}=App.state;
  const payload={version:1,coordinate_system:'screen_pixels_not_GIS',canvas:{width:1000,height:700},
    map_source_canvas:{width:900,height:500},background:photo?'user_photo':'saved_seoul_map',
    note:'사진 파일은 포함하지 않습니다. 화면 좌표이며 실제 토지 면적이나 GIS 경계가 아닙니다.',...data,
    coverage_pixels:App.coverage(App.state.rectangles)};
  const url=URL.createObjectURL(new Blob([JSON.stringify(payload,null,2)],{type:'application/json'}));
  const a=document.createElement('a');a.href=url;a.download='regreen-design.json';a.click();
  setTimeout(()=>URL.revokeObjectURL(url),1000);
};
