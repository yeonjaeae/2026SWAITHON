/* 공통 상태 · SVG 렌더링 · 사각형 편집. 외부 요청을 보내지 않습니다. */
const App = (() => {
  const key = 'regreen.frontend.v3';
  const ns = 'http://www.w3.org/2000/svg';
  const empty = () => ({name:'', region:null, rectangles:[], vegetation:[], conditions:[], memo:'', photo:null, vegetationMix:{grass:50,shrub:30,tree:20}});
  let state = empty();
  try { state = {...state, ...JSON.parse(sessionStorage.getItem(key) || '{}')}; } catch (_) {}
  function save() {
    try { sessionStorage.setItem(key, JSON.stringify(state)); return true; }
    catch (_) { alert('설계 내용을 저장하지 못했습니다. 브라우저 저장 설정이나 이미지 용량을 확인해 주세요.'); return false; }
  }
  function svg(tag, attrs = {}) {
    const node = document.createElementNS(ns, tag);
    for (const [name, value] of Object.entries(attrs)) node.setAttribute(name, value);
    return node;
  }
  function rect(a,b,kind='green') {
    return {x:Math.min(a.x,b.x), y:Math.min(a.y,b.y), width:Math.abs(a.x-b.x), height:Math.abs(a.y-b.y), kind};
  }
  // 축별 경계로 잘라 합집합을 계산합니다. 녹화와 보존이 겹치면 보존 우선.
  function coverage(rectangles) {
    if (!rectangles.length) return {green:0, protect:0};
    const xs = [...new Set(rectangles.flatMap(r => [r.x,r.x+r.width]))].sort((a,b)=>a-b);
    let green = 0, protect = 0;
    for (let i=1; i<xs.length; i++) {
      const x=(xs[i-1]+xs[i])/2;
      const active=rectangles.filter(r=>x>=r.x&&x<r.x+r.width);
      const ys=[...new Set(active.flatMap(r=>[r.y,r.y+r.height]))].sort((a,b)=>a-b);
      for(let j=1;j<ys.length;j++) {
        const y=(ys[j-1]+ys[j])/2;
        const hit=active.filter(r=>y>=r.y&&y<r.y+r.height);
        const area=(xs[i]-xs[i-1])*(ys[j]-ys[j-1]);
        if(hit.some(r=>r.kind==='protect')) protect+=area;
        else if(hit.some(r=>r.kind==='green')) green+=area;
      }
    }
    return {green,protect};
  }
  const percent = n => (n/700000*100).toFixed(1)+'%';
  function drawRects(group, rectangles) {
    group.replaceChildren();
    // 보존 영역을 마지막에 그려 시각적으로도 우선 표시합니다.
    for (const r of [...rectangles.filter(r=>r.kind==='green'), ...rectangles.filter(r=>r.kind==='protect')]) {
      group.append(svg('rect',{x:r.x,y:r.y,width:r.width,height:r.height,
        fill:r.kind==='protect'?'#e4b34d':'#619b65','fill-opacity':'.43',
        stroke:r.kind==='protect'?'#a06a10':'#285d38','stroke-width':2,'vector-effect':'non-scaling-stroke'}));
    }
  }
  function renderMap(target, rectangles=state.rectangles) {
    target.replaceChildren();
    if(state.photo) target.append(svg('image',{href:state.photo,width:1000,height:700,preserveAspectRatio:'xMidYMid slice'}));
    else {
      const r=state.region || {x:0,y:0,width:900,height:500};
      const nested=svg('svg',{width:1000,height:700,viewBox:`${r.x} ${r.y} ${r.width} ${r.height}`,preserveAspectRatio:'none'});
      nested.append(svg('image',{href:'assets/image-02.webp',width:900,height:500}));target.append(nested);
    }
    const layer=svg('g');drawRects(layer,rectangles);target.append(layer);return layer;
  }
  function bindDrawing(target,{width,height,onPreview,onCommit,enabled=()=>true}) {
    let start=null, pointer=null;
    function point(event) {
      const matrix=target.getScreenCTM();
      if(!matrix)return {x:0,y:0};
      const p=new DOMPoint(event.clientX,event.clientY).matrixTransform(matrix.inverse());
      return {x:Math.max(0,Math.min(width,p.x)),y:Math.max(0,Math.min(height,p.y))};
    }
    function cancel() { start=null;pointer=null;onPreview(null); }
    target.addEventListener('pointerdown',event=>{
      if(!enabled()||!event.isPrimary||event.button!==0)return;
      event.preventDefault();start=point(event);pointer=event.pointerId;
      target.setPointerCapture(pointer);
    });
    target.addEventListener('pointermove',event=>{
      if(start&&event.pointerId===pointer)onPreview(rect(start,point(event)));
    });
    target.addEventListener('pointerup',event=>{
      if(!start||event.pointerId!==pointer)return;
      const box=rect(start,point(event));start=null;pointer=null;
      if(target.hasPointerCapture(event.pointerId))target.releasePointerCapture(event.pointerId);
      onPreview(null);
      if(box.width>=8&&box.height>=8)onCommit(box);
    });
    target.addEventListener('pointercancel',cancel);
    target.addEventListener('lostpointercapture',()=>{if(start)cancel();});
    document.addEventListener('keydown',event=>{if(event.key==='Escape')cancel();});
  }
  // 고정된 원본 좌표계를 유지하므로 확대해도 사각형의 위치·비율은 변하지 않습니다.
  function bindCamera(target,{width,height,canPan,onChange=()=>{}}) {
    let camera={x:0,y:0,width,height}, drag=null;
    const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
    function apply(){
      camera.x=clamp(camera.x,0,width-camera.width);
      camera.y=clamp(camera.y,0,height-camera.height);
      target.setAttribute('viewBox',`${camera.x} ${camera.y} ${camera.width} ${camera.height}`);
      onChange(Math.round(width/camera.width*100));
    }
    function zoom(factor,anchor){
      const p=anchor||{x:camera.x+camera.width/2,y:camera.y+camera.height/2};
      const nextWidth=clamp(camera.width/factor,width/12,width);
      const ratio=nextWidth/camera.width;
      camera={x:p.x-(p.x-camera.x)*ratio,y:p.y-(p.y-camera.y)*ratio,width:nextWidth,height:nextWidth*height/width};apply();
    }
    target.addEventListener('wheel',e=>{
      e.preventDefault();if(drag)return;
      const p=new DOMPoint(e.clientX,e.clientY).matrixTransform(target.getScreenCTM().inverse());
      zoom(e.deltaY<0?1.2:1/1.2,p);
    },{passive:false});
    target.addEventListener('pointerdown',e=>{
      if(!canPan()||!e.isPrimary||e.button!==0)return;
      e.preventDefault();drag={id:e.pointerId,x:e.clientX,y:e.clientY,camera:{...camera},inverse:target.getScreenCTM().inverse()};
      target.setPointerCapture(e.pointerId);target.style.cursor='grabbing';
    });
    target.addEventListener('pointermove',e=>{
      if(!drag||e.pointerId!==drag.id)return;
      const a=new DOMPoint(drag.x,drag.y).matrixTransform(drag.inverse);
      const b=new DOMPoint(e.clientX,e.clientY).matrixTransform(drag.inverse);
      camera.x=drag.camera.x+a.x-b.x;camera.y=drag.camera.y+a.y-b.y;apply();
    });
    function finish(){drag=null;target.style.cursor=canPan()?'grab':'crosshair';}
    target.addEventListener('pointerup',finish);target.addEventListener('pointercancel',finish);target.addEventListener('lostpointercapture',finish);
    apply();return {zoom,reset(){camera={x:0,y:0,width,height};apply();}};
  }
  function rebalanceMix(mix,key,value){
    const other=['grass','shrub','tree'].filter(k=>k!==key);
    const available=100-value, sum=mix[other[0]]+mix[other[1]];
    const a=Math.round(available*(sum?mix[other[0]]/sum:.5));
    return {...mix,[key]:value,[other[0]]:a,[other[1]]:available-a};
  }
  function summary() {
    const {green,protect}=coverage(state.rectangles);
    return `표시한 녹화 비율 ${percent(green)} · 보존 비율 ${percent(protect)}\n식생: 잔디 ${state.vegetationMix.grass}% · 관목 ${state.vegetationMix.shrub}% · 교목 ${state.vegetationMix.tree}%\n공존 조건: 직접 그린 보존 영역 우선`;
  }
  document.querySelectorAll('nav a').forEach(a=>{
    if(a.getAttribute('href')===document.body.dataset.page+'.html')a.setAttribute('aria-current','page');
  });
  return {state,save,svg,rect,coverage,percent,drawRects,renderMap,bindDrawing,bindCamera,rebalanceMix,summary};
})();
// 뒤로 가기로 돌아왔을 때 다른 페이지에서 저장한 설계를 다시 읽습니다.
window.addEventListener('pageshow', event => { if (event.persisted) location.reload(); });
